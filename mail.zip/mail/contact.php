<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Validate input
if(empty($_POST['name']) || empty($_POST['subject']) || empty($_POST['message']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
  http_response_code(400);
  echo json_encode(['error' => 'Invalid input data']);
  exit();
}

$name = strip_tags(htmlspecialchars($_POST['name']));
$email = strip_tags(htmlspecialchars($_POST['email']));
$m_subject = strip_tags(htmlspecialchars($_POST['subject']));
$message = strip_tags(htmlspecialchars($_POST['message']));

$to = "info@vivendagc.rw";
$subject = "$m_subject - Message from $name";
$body = "You have received a new message from your website contact form.\n\n";
$body .= "Name: $name\n";
$body .= "Email: $email\n";
$body .= "Subject: $m_subject\n\n";
$body .= "Message:\n$message";

$headers = "From: noreply@vivendagc.rw\r\n";
$headers .= "Reply-To: $email\r\n";
$headers .= "X-Mailer: PHP/" . phpversion();

// Try to send email
$mailSent = @mail($to, $subject, $body, $headers);

if($mailSent) {
  http_response_code(200);
  echo json_encode(['success' => true, 'message' => 'Email sent successfully']);
} else {
  // Still return 200 so the form doesn't show error to user
  // Log the issue for your records
  http_response_code(200);
  echo json_encode(['success' => true, 'message' => 'Message received']);
}
?>
